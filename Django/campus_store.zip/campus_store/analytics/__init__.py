default_app_config = "campus_store.analytics.apps.AnalyticsConfig"
