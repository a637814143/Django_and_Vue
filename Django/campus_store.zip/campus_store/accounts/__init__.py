default_app_config = "campus_store.accounts.apps.AccountsConfig"
