default_app_config = "campus_store.catalog.apps.CatalogConfig"
