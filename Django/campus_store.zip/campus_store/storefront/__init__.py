"""
Storefront-facing APIs for exposing merchants and their products to consumers.
"""
