default_app_config = "campus_store.focus.apps.FocusConfig"
