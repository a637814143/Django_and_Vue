default_app_config = "campus_store.wallet.apps.WalletConfig"
